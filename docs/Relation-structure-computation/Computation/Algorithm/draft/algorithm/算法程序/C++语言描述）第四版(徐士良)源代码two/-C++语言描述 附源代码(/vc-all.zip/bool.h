
#ifndef bool_
#define bool_

typedef int bool;
const bool false = 0;
const bool true = 1;

#endif
